####### Imports #######
import tkinter as tk
from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
import numpy as np
from PIL import Image, ImageDraw
import subprocess
import customtkinter
import sqlite3

def generate():
    selected_category = category_combobox.get()
    selected_workout = workouts_combobox.get()

    # Establish a connection to the database
    conn = sqlite3.connect('workouts.db')
    # Create a cursor object
    cursor = conn.cursor()

    # Execute a SELECT statement to retrieve the workout information
    cursor.execute("SELECT name, type, reps, weight, sets FROM workouts WHERE type=? AND name=?", (selected_category, selected_workout))
    workout_data = cursor.fetchone()

    # Close the connection
    conn.close()

    # Display the retrieved workout information
    if workout_data:
        name, type, reps, weight, sets = workout_data

        name_var.set(name)
        type_var.set(type)
        reps_var.set(reps)
        weight_var.set(weight)
        sets_var.set(sets)

        workout_label_updated = ttk.Label(top_frame, textvariable=name_var)
        workout_label_updated.grid(row=3, column=1)

        workout_label_updated2 = ttk.Label(top_frame, textvariable=type_var)
        workout_label_updated2.grid(row=4, column=1)

        workout_label_updated3 = ttk.Label(top_frame, textvariable=reps_var)
        workout_label_updated3.grid(row=5, column=1)

        workout_label_updated4 = ttk.Label(top_frame, textvariable=weight_var)
        workout_label_updated4.grid(row=6, column=1)

        workout_label_updated5 = ttk.Label(top_frame, textvariable=sets_var)
        workout_label_updated5.grid(row=7, column=1)


# Update the variable values

def update_second_combo(event):
    selected_item = category_combobox.get()
    workouts_combobox['values'] = combo_values[selected_item]

# Establish a connection to the database
conn = sqlite3.connect('workouts.db')
# Create a cursor object
cursor = conn.cursor()
# Execute an SQL statement to create a table
cursor.execute("CREATE TABLE workouts (id INTEGER PRIMARY KEY, name TEXT, type TEXT, reps INTEGER, weight INTEGER, sets INTEGER)")
# Execute an SQL statement to insert a workout
# weight will change depending on the max of each type 
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Calf Raises','Legs',15,50,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Leg-Press','Legs',12,180,3)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Squat','Legs',15,80,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Walking Lunges','Legs',15,30,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Leg Extension','Legs',15,30,5)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Hack Squat','Legs',12,60,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Romanian Deadlift','Legs',8,40,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Deadlift','Legs',8,100,3)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Hamstring Curl','Legs',15,30,4)")

cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Bicep Curl','Arms',15,25,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Ben-Over Rows','Arms',12,20,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Hammer Curl','Arms',15,20,5)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Dips','Arms',12,0,3)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Push-Downs','Arms',15,30,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Tricep Extension','Arms',15,15,3)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Shoulder Press','Arms',12,20,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Lateral Raises','Arms',8,10,3)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Incline Bicep Curl','Arms',12,10,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Pull-Ups','Arms',15,0,4)")

cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Bench-Press','Chest',12,25,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Chest-Fly','Chest',15,25,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Push-Ups','Chest',30,25,3)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Cable Crossovers','Chest',12,25,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Tricep Extension','Chest',12,25,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Chest Dip','Chest',15,25,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Overhead Press','Chest',12,25,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Wide Grip Bench-Press','Chest',12,25,4)")
cursor.execute("INSERT INTO workouts (name,type,reps,weight,sets) VALUES ('Decline Push-Ups','Chest',30,25,2)")

# Commit the changes
conn.commit()
conn.close()

combo_values = {
    'Legs': ['Calf Raises', 'Leg-Press', 'Squat','Walking Lunges','Leg Extension','Hack Squat','Romanian Deadlift','Deadlift','Hamstring Curl'],
    'Arms': ['Bicep Curl', 'Bent-Over Rows', 'Hammer Curl','Dips','Push-Downs','Tricep Extension','Shoulder Press','Lateral Raises','Incline Bicep Curl','Pull-Ups'],
    'Chest': ['Bench-Press', 'Chest-Fly', 'Push-Ups','Cable Crossovers','Tricep Extension','Chest Dip','Overhead Press','Tricep Dips','Wide Grip Bench-Press','Decline Push-Ups'],
}



root = Tk()
root.geometry("640x960")
root.title("Data page")
root.resizable(width=False, height=False)

name_var = StringVar()
type_var = StringVar()
reps_var = IntVar()
weight_var = IntVar()
sets_var = IntVar()

top_frame = ttk.LabelFrame(root)
top_frame.grid(row = 1, column=1, columnspan=3, sticky="NE", padx=70)

catagory_label = ttk.Label(top_frame,text="Catagory:", font=("Helvetica", 18))
catagory_label.grid(row=0, column=0 , padx=20, pady=5)

workout_label = ttk.Label(top_frame,text="Workout:", font=("Helvetica", 18))
workout_label.grid(row=0, column=2 , padx=20, pady=5)

generate_button = ttk.Button(top_frame,text="Generate",command=generate)
generate_button.grid(row=2, column=1)

#create a drop down box for catagories
categories = ["Legs", "Arms", "Chest"]
category_combobox = ttk.Combobox(top_frame,values=list(combo_values.keys()) ,state='readonly')
category_combobox.bind('<<ComboboxSelected>>', update_second_combo)
category_combobox.grid(row=1, column=0, padx=10, pady=10)

#create a drop down box for catagories
#workouts set for now (objects later)

workouts_combobox = ttk.Combobox(top_frame, state='readonly')
workouts_combobox.grid(row=1, column=2, padx=10, pady=10)



root.mainloop()
