import tkinter as tk
import random
import sqlite3

# Connect to the SQLite database
conn = sqlite3.connect('workouts_generate.db')
cursor = conn.cursor()

# Drop the existing workouts table if it exists
cursor.execute("DROP TABLE IF EXISTS workouts")

# Create the workouts table with the correct column structure
cursor.execute('''CREATE TABLE workouts
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                description TEXT)''')

# Insert some sample workouts into the table
cursor.execute("INSERT INTO workouts (name, description) VALUES (?, ?)", ("Push-ups", "Do 3 sets of 10 push-ups."))
cursor.execute("INSERT INTO workouts (name, description) VALUES (?, ?)", ("Squats", "Do 4 sets of 12 squats."))
cursor.execute("INSERT INTO workouts (name, description) VALUES (?, ?)", ("Plank", "Hold the plank position for 1 minute."))

# Commit the changes and close the connection
conn.commit()
conn.close()

# Create a GUI application
root = tk.Tk()

# Function to select a random workout
def select_random_workout():
    # Connect to the SQLite database
    conn = sqlite3.connect('workouts_generate.db')
    cursor = conn.cursor()

    # Fetch all the workouts from the table
    cursor.execute("SELECT * FROM workouts")
    workouts = cursor.fetchall()

    # Select a random workout
    random_workout = random.choice(workouts)

    # Display the selected workout
    workout_name.config(text=random_workout[1])
    workout_description.config(text=random_workout[2])

    # Close the connection
    conn.close()

# Create a button to select a random workout
select_button = tk.Button(root, text="Select Random Workout", command=select_random_workout)
select_button.pack()

# Label to display the selected workout
workout_name = tk.Label(root, text="")
workout_name.pack()
workout_description = tk.Label(root, text="")
workout_description.pack()

# Run the GUI application
root.mainloop()
