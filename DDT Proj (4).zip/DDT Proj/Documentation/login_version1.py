####### Imports #######
import tkinter as tk
from tkinter import *
from tkinter import ttk
import numpy as np
from PIL import Image, ImageDraw, ImageTk
import subprocess
from tkinter import messagebox

####### Class Code #######

class User:
    def __init__(self, email, password, name, dob):
        self.email = email
        self.password = password
        self.name = name
        self.dob = dob

    def save_to_file(self):
        with open("user_data.txt", "a") as file:
            file.write(f"{self.email},{self.password},{self.name},{self.dob}\n")

# ...

def error_login():
    messagebox.showerror('Login Error', 'Error: Login or password are incorrect!')

def login():
    email = email_entered.get().strip()
    password = password_entred.get().strip()

    with open("user_data.txt", "r") as file:
        lines = file.readlines()
        for line in reversed(lines):  # Iterate in reverse order so it reads most resent update in history
            stored_email, stored_password, _, _ = line.strip().split(",", maxsplit=3)

            print(f"Entered email: {email}")
            print(f"Entered password: {password}")
            print(f"Stored email: {stored_email}")
            print(f"Stored password: {stored_password}")

            if email == stored_email and password == stored_password:
                print("Login successful")
                root.destroy()
                subprocess.Popen(["python", "Documentation/homepage_version1.py"])
                return
        error_login()

def sign_up():
    email = email_entry_signup.get()
    password = password_entry_signup.get()
    name = name_entered_signup.get()
    dob = dob_entered_signup.get()

    user = User(email, password, name, dob)
    user.save_to_file()
    root.destroy()
    subprocess.Popen(["python","Documentation/homepage_version1.py"])


####### GUI code #######

root = Tk()
root.geometry("640x960")
root.title("Login/Sign-up page")



background_image = tk.PhotoImage(file="assets/Project Walpaper.png")
background_label = ttk.Label(root, image=background_image)
background_label.place(x=0, y=0,relwidth=1,relheight=1)



logo_image = PhotoImage(file="assets/DDT Wireframe Homepage.png")
logo_label = ttk.Label(root, image=logo_image)
logo_label.grid(row=0, column= 1, columnspan=2, pady = 50, padx = "220")


top_frame = ttk.LabelFrame(root, text="Login")
top_frame.grid(row=7, column=1, padx=10, pady=10, sticky="N",columnspan=4)

email_label = ttk.Label(top_frame, text = "Email:", wraplength=250)
email_label.grid(row=0, column=0, columnspan=2, padx=5, pady=5)
email_entered = StringVar()

email_entry = ttk.Entry(top_frame, textvariable = email_entered)
email_entry.grid(row=3, column=0, columnspan=2,padx=5, pady=5, ipadx = 45)

password_label = ttk.Label(top_frame, text = "Password:",wraplength=250)
password_label.grid(row=4, column=0, columnspan =2, padx=5, pady=5, rowspan=1)
password_entred = StringVar()

password_entry = ttk.Entry(top_frame, textvariable = password_entred, show="*")
password_entry.grid(row=5, column=0, columnspan =2, padx=5, pady=5, ipadx = 45)

#command 
login_radio_button = ttk.Button(top_frame, text="Login", command=login)
login_radio_button.grid(row=6, column=0 ,pady=10, columnspan=2 )

bottom_frame = ttk.LabelFrame(root, text="Sign-Up")
bottom_frame.grid(row=10, column=1, pady=10, sticky="N", padx=220)

email_label_signup = ttk.Label(bottom_frame, text = "Email:", wraplength=250)
email_label_signup.grid(row=0, column=0, columnspan=2, padx=5, pady=5)
email_entered_signup = StringVar()

email_entry_signup = ttk.Entry(bottom_frame, textvariable = email_entered_signup)
email_entry_signup.grid(row=1, column=0, columnspan =2, padx=5, pady=5, ipadx = 45)

password_label_signup = ttk.Label(bottom_frame, text = "Password:", wraplength=250)
password_label_signup.grid(row=2, column=0, columnspan =2, padx=5, pady=5)
password_entred_signup = StringVar()

password_entry_signup = ttk.Entry(bottom_frame, textvariable = password_entred_signup, show="*")
password_entry_signup.grid(row=3, column=0, columnspan =2, padx=5, pady=5, ipadx = 45)

name_label_signup = ttk.Label(bottom_frame,text="Name:", wraplength=250)
name_label_signup.grid(row=4 ,column=0, columnspan =2, padx=5, pady = 5)
name_entered_signup = StringVar()

name_entry_signup = ttk.Entry(bottom_frame, textvariable=name_entered_signup)
name_entry_signup.grid(row=5, column=0, padx= 5, pady =5 , ipadx = 45)

dob_label_signup = ttk.Label(bottom_frame,text="Date of birth:", wraplength=250)
dob_label_signup.grid(row=6 ,column=0, columnspan =2, padx=5, pady = 5)
label_under_dob = ttk.Label(bottom_frame, text="Day/Month/Year", font=("Helvetica", 12))
label_under_dob.grid(row = 7, pady=4)

# Change the font size of the label's text
label_under_dob.config(font=("Helvetica",8))
dob_entered_signup = StringVar()

dob_entry_signup = ttk.Entry(bottom_frame, textvariable=dob_entered_signup)
dob_entry_signup.grid(row=8, column=0, padx= 5, pady =5 , ipadx = 45)

#command 
signup_button = ttk.Button(bottom_frame, text="Sign-Up", command=sign_up)
signup_button.grid(row=9, column=0 ,pady=10, columnspan=2 )

root.mainloop()

